<html>
 <head>
  <title>List of Products</title>
   </head>
    <body>
<p><h2>Here is the list of our Products. Click on any of the product to view the details</h2></p>
     <li>
       <?php
 
 $connect=mysqli_connect('localhost','root','','trialdb');	
       //check connection
  // if(mysqli_connect_errno($connect))
  // {
  //	echo 'Failed to connect to database: '.mysqli_connect_error();
  // }
  // else
  //	echo 'Connected Successfully!!';

  $list = mysqli_query($connect,"SELECT * FROM products_prices");
        while($row=mysqli_fetch_array($list))
          {
         echo $row['Product_type'];
	
      echo "<li><a href = 'productdetails.php?>' </li>";
    }
	mysqli_close($connect);
	?>
     </li>
    </body>
  </html>
