<!DOCTYPE html>

<html>
   <head>
      <meta charset = "utf-8">
      <title>Search Results</title>
   <style type = "text/css">
         body  { font-family: sans-serif;
                 background-color: lightyellow; } 
         table { background-color: lightblue; 
                 border-collapse: collapse; 
                 border: 1px solid gray; }
         td    { padding: 5px; }
         tr:nth-child(odd) {
                 background-color: white; }
      </style>
   </head>
   <body>
      <?php
 $connect=mysqli_connect("localhost","root","","trialdb");
      ?><!-- end PHP script -->
      <table>
         <caption>Results of SELECT FROM products_prices</caption>
         <?php

            // fetch each record in result set
 $result = mysqli_query($connect, "SELECT * FROM products_prices");
            while ( $row = mysqli_fetch_row( $result ) )
            {
               // build table to display results
               print( "<tr>" );

               foreach ( $row as $value ) 
                  print( "<td>$value</td>" );

               print( "</tr>" );
            } // end while
         ?><!-- end PHP script -->
      </table>
      <p>Your search yielded 
         <?php print( mysqli_num_rows( $result ) ) ?> results.</p>
      <p><a href="productlist.php">Return to the Productlist</a></p>
   </body>
</html>