DROP TABLE products_prices;

CREATE TABLE products_prices
(

        Id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
	Product_type VARCHAR (500) NOT NULL,
	Prices per kilo VARCHAR (500) NOT NULL,
	Availability VARCHAR (500) NOT NULL
);

INSERT INTO products_prices (Id,Product_type,Prices_per_kilo,Availability)
		VALUES ('1', 'cow head', '$8', 'yes'),
			('2', 'cow meat', '$4', 'yes'),
			('3', 'cow intestine', '$1', 'yes'),
			('4', 'ponmo', '$3', 'yes'),
			('5', 'shaki', '$3', 'today out of stock');